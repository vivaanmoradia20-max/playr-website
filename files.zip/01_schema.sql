-- ============================================================
-- PLAYR — Supabase Schema
-- Run this in Supabase SQL Editor (or via `supabase db push`)
-- Order: 01_schema.sql -> 02_rls_policies.sql -> 03_storage.sql
-- ============================================================

create extension if not exists "pgcrypto";

-- ============================================================
-- PROFILES  (1:1 with auth.users)
-- ============================================================
create table if not exists public.profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  username        text unique not null,
  display_name    text,
  bio             text,
  location        text,
  avatar_url      text,
  is_playr_plus   boolean default false,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- ============================================================
-- SPORTS
-- ============================================================
create table if not exists public.sports (
  id              uuid primary key default gen_random_uuid(),
  name            text unique not null,
  category        text,
  description     text,
  image_url       text,
  follower_count  integer default 0,
  created_at      timestamptz default now()
);

-- ============================================================
-- USER_SPORTS (follow a sport)
-- ============================================================
create table if not exists public.user_sports (
  user_id     uuid references public.profiles(id) on delete cascade,
  sport_id    uuid references public.sports(id) on delete cascade,
  created_at  timestamptz default now(),
  primary key (user_id, sport_id)
);

-- ============================================================
-- COMMUNITIES
-- ============================================================
create table if not exists public.communities (
  id              uuid primary key default gen_random_uuid(),
  name            text not null,
  slug            text unique,
  description     text,
  image_url       text,
  sport_id        uuid references public.sports(id) on delete set null,
  member_count    integer default 0,
  created_by      uuid references public.profiles(id) on delete set null,
  created_at      timestamptz default now()
);

create table if not exists public.community_members (
  community_id  uuid references public.communities(id) on delete cascade,
  user_id       uuid references public.profiles(id) on delete cascade,
  role          text default 'member', -- 'owner' | 'member'
  joined_at     timestamptz default now(),
  primary key (community_id, user_id)
);

-- ============================================================
-- POSTS
-- ============================================================
create table if not exists public.posts (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid references public.profiles(id) on delete cascade,
  sport_id        uuid references public.sports(id) on delete set null,
  community_id    uuid references public.communities(id) on delete set null,
  caption         text,
  media_url       text,
  like_count      integer default 0,
  comment_count   integer default 0,
  created_at      timestamptz default now()
);

create index if not exists idx_posts_created_at on public.posts (created_at desc);
create index if not exists idx_posts_user on public.posts (user_id);
create index if not exists idx_posts_sport on public.posts (sport_id);
create index if not exists idx_posts_community on public.posts (community_id);

-- ============================================================
-- FOLLOWS (user -> user)
-- ============================================================
create table if not exists public.follows (
  follower_id   uuid references public.profiles(id) on delete cascade,
  following_id  uuid references public.profiles(id) on delete cascade,
  created_at    timestamptz default now(),
  primary key (follower_id, following_id),
  constraint no_self_follow check (follower_id <> following_id)
);

-- ============================================================
-- LIKES
-- ============================================================
create table if not exists public.likes (
  user_id     uuid references public.profiles(id) on delete cascade,
  post_id     uuid references public.posts(id) on delete cascade,
  created_at  timestamptz default now(),
  primary key (user_id, post_id)
);

-- ============================================================
-- COMMENTS
-- ============================================================
create table if not exists public.comments (
  id          uuid primary key default gen_random_uuid(),
  post_id     uuid references public.posts(id) on delete cascade,
  user_id     uuid references public.profiles(id) on delete cascade,
  comment     text not null,
  created_at  timestamptz default now()
);

create index if not exists idx_comments_post on public.comments (post_id);

-- ============================================================
-- CHALLENGES
-- ============================================================
create table if not exists public.challenges (
  id              uuid primary key default gen_random_uuid(),
  creator_id      uuid references public.profiles(id) on delete cascade,
  opponent_id     uuid references public.profiles(id) on delete set null,
  sport_id        uuid references public.sports(id) on delete set null,
  title           text not null,
  description     text,
  unit            text default 'time', -- 'time' | 'distance' | 'reps' | 'score'
  target_value    text,                 -- e.g. "10 KM"
  status          text default 'pending', -- pending | accepted | declined | completed
  created_at      timestamptz default now()
);

create table if not exists public.challenge_results (
  id              uuid primary key default gen_random_uuid(),
  challenge_id    uuid references public.challenges(id) on delete cascade,
  user_id         uuid references public.profiles(id) on delete cascade,
  result_value    numeric,
  result_display  text, -- e.g. "57:42"
  submitted_at    timestamptz default now()
);

create index if not exists idx_challenge_results_challenge on public.challenge_results (challenge_id);

-- ============================================================
-- EVENTS
-- ============================================================
create table if not exists public.events (
  id              uuid primary key default gen_random_uuid(),
  name            text not null,
  description     text,
  sport_id        uuid references public.sports(id) on delete set null,
  location        text,
  banner_image_url text,
  start_date      timestamptz,
  end_date        timestamptz,
  follower_count  integer default 0,
  created_by      uuid references public.profiles(id) on delete set null,
  created_at      timestamptz default now()
);

create table if not exists public.event_registrations (
  event_id      uuid references public.events(id) on delete cascade,
  user_id       uuid references public.profiles(id) on delete cascade,
  registered_at timestamptz default now(),
  primary key (event_id, user_id)
);

create table if not exists public.event_follows (
  event_id    uuid references public.events(id) on delete cascade,
  user_id     uuid references public.profiles(id) on delete cascade,
  created_at  timestamptz default now(),
  primary key (event_id, user_id)
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
create table if not exists public.notifications (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid references public.profiles(id) on delete cascade, -- recipient
  actor_id      uuid references public.profiles(id) on delete set null, -- who triggered it
  type          text not null, -- follow | like | comment | challenge | challenge_accepted | event_registration
  entity_type   text,          -- post | challenge | event | profile
  entity_id     uuid,
  message       text,
  is_read       boolean default false,
  created_at    timestamptz default now()
);

create index if not exists idx_notifications_user on public.notifications (user_id, created_at desc);

-- ============================================================
-- SUBSCRIPTIONS (PLAYR+)
-- ============================================================
create table if not exists public.subscriptions (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid unique references public.profiles(id) on delete cascade,
  plan          text default 'PLAYR+',
  status        text default 'inactive', -- inactive | active | cancelled
  started_at    timestamptz,
  expires_at    timestamptz,
  created_at    timestamptz default now()
);

-- ============================================================
-- SHOP: PRODUCTS + CART
-- ============================================================
create table if not exists public.products (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  category    text,
  description text,
  price       numeric not null,
  image_url   text,
  stock       integer default 100,
  created_at  timestamptz default now()
);

create table if not exists public.cart_items (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid references public.profiles(id) on delete cascade,
  product_id  uuid references public.products(id) on delete cascade,
  quantity    integer not null default 1 check (quantity > 0),
  created_at  timestamptz default now(),
  unique (user_id, product_id)
);

-- ============================================================
-- updated_at trigger for profiles
-- ============================================================
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

-- ============================================================
-- Auto-create a profile row whenever a new auth user signs up
-- ============================================================
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1) || '_' || substr(new.id::text,1,4)),
    coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'username')
  )
  on conflict (id) do nothing;

  insert into public.subscriptions (user_id, plan, status)
  values (new.id, 'PLAYR+', 'inactive')
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- ============================================================
-- Counter maintenance triggers
-- ============================================================

-- sports.follower_count
create or replace function public.bump_sport_follower_count()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.sports set follower_count = follower_count + 1 where id = new.sport_id;
  elsif tg_op = 'DELETE' then
    update public.sports set follower_count = greatest(follower_count - 1, 0) where id = old.sport_id;
  end if;
  return null;
end;
$$;

drop trigger if exists trg_user_sports_count on public.user_sports;
create trigger trg_user_sports_count
after insert or delete on public.user_sports
for each row execute function public.bump_sport_follower_count();

-- posts.like_count
create or replace function public.bump_post_like_count()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.posts set like_count = like_count + 1 where id = new.post_id;
  elsif tg_op = 'DELETE' then
    update public.posts set like_count = greatest(like_count - 1, 0) where id = old.post_id;
  end if;
  return null;
end;
$$;

drop trigger if exists trg_likes_count on public.likes;
create trigger trg_likes_count
after insert or delete on public.likes
for each row execute function public.bump_post_like_count();

-- posts.comment_count
create or replace function public.bump_post_comment_count()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.posts set comment_count = comment_count + 1 where id = new.post_id;
  elsif tg_op = 'DELETE' then
    update public.posts set comment_count = greatest(comment_count - 1, 0) where id = old.post_id;
  end if;
  return null;
end;
$$;

drop trigger if exists trg_comments_count on public.comments;
create trigger trg_comments_count
after insert or delete on public.comments
for each row execute function public.bump_post_comment_count();

-- communities.member_count
create or replace function public.bump_community_member_count()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.communities set member_count = member_count + 1 where id = new.community_id;
  elsif tg_op = 'DELETE' then
    update public.communities set member_count = greatest(member_count - 1, 0) where id = old.community_id;
  end if;
  return null;
end;
$$;

drop trigger if exists trg_community_members_count on public.community_members;
create trigger trg_community_members_count
after insert or delete on public.community_members
for each row execute function public.bump_community_member_count();

-- events.follower_count
create or replace function public.bump_event_follower_count()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.events set follower_count = follower_count + 1 where id = new.event_id;
  elsif tg_op = 'DELETE' then
    update public.events set follower_count = greatest(follower_count - 1, 0) where id = old.event_id;
  end if;
  return null;
end;
$$;

drop trigger if exists trg_event_follows_count on public.event_follows;
create trigger trg_event_follows_count
after insert or delete on public.event_follows
for each row execute function public.bump_event_follower_count();

-- when a community is created, the creator auto-joins as owner
create or replace function public.auto_join_own_community()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.created_by is not null then
    insert into public.community_members (community_id, user_id, role)
    values (new.id, new.created_by, 'owner')
    on conflict do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_auto_join_community on public.communities;
create trigger trg_auto_join_community
after insert on public.communities
for each row execute function public.auto_join_own_community();

-- ============================================================
-- Notification triggers
-- ============================================================

-- new follower
create or replace function public.notify_on_follow()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.notifications (user_id, actor_id, type, entity_type, entity_id, message)
  values (new.following_id, new.follower_id, 'follow', 'profile', new.follower_id, 'started following you');
  return new;
end;
$$;

drop trigger if exists trg_notify_follow on public.follows;
create trigger trg_notify_follow
after insert on public.follows
for each row execute function public.notify_on_follow();

-- new like
create or replace function public.notify_on_like()
returns trigger language plpgsql security definer set search_path = public as $$
declare post_owner uuid;
begin
  select user_id into post_owner from public.posts where id = new.post_id;
  if post_owner is not null and post_owner <> new.user_id then
    insert into public.notifications (user_id, actor_id, type, entity_type, entity_id, message)
    values (post_owner, new.user_id, 'like', 'post', new.post_id, 'liked your post');
  end if;
  return new;
end;
$$;

drop trigger if exists trg_notify_like on public.likes;
create trigger trg_notify_like
after insert on public.likes
for each row execute function public.notify_on_like();

-- new comment
create or replace function public.notify_on_comment()
returns trigger language plpgsql security definer set search_path = public as $$
declare post_owner uuid;
begin
  select user_id into post_owner from public.posts where id = new.post_id;
  if post_owner is not null and post_owner <> new.user_id then
    insert into public.notifications (user_id, actor_id, type, entity_type, entity_id, message)
    values (post_owner, new.user_id, 'comment', 'post', new.post_id, 'commented on your post');
  end if;
  return new;
end;
$$;

drop trigger if exists trg_notify_comment on public.comments;
create trigger trg_notify_comment
after insert on public.comments
for each row execute function public.notify_on_comment();

-- challenge created / accepted
create or replace function public.notify_on_challenge()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' and new.opponent_id is not null then
    insert into public.notifications (user_id, actor_id, type, entity_type, entity_id, message)
    values (new.opponent_id, new.creator_id, 'challenge', 'challenge', new.id, 'challenged you: ' || new.title);
  elsif tg_op = 'UPDATE' and new.status = 'accepted' and old.status is distinct from 'accepted' then
    insert into public.notifications (user_id, actor_id, type, entity_type, entity_id, message)
    values (new.creator_id, new.opponent_id, 'challenge_accepted', 'challenge', new.id, 'accepted your challenge: ' || new.title);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_notify_challenge on public.challenges;
create trigger trg_notify_challenge
after insert or update on public.challenges
for each row execute function public.notify_on_challenge();

-- event registration -> notify event creator
create or replace function public.notify_on_event_registration()
returns trigger language plpgsql security definer set search_path = public as $$
declare organizer uuid;
declare ev_name text;
begin
  select created_by, name into organizer, ev_name from public.events where id = new.event_id;
  if organizer is not null and organizer <> new.user_id then
    insert into public.notifications (user_id, actor_id, type, entity_type, entity_id, message)
    values (organizer, new.user_id, 'event_registration', 'event', new.event_id, 'registered for ' || coalesce(ev_name, 'your event'));
  end if;
  return new;
end;
$$;

drop trigger if exists trg_notify_event_registration on public.event_registrations;
create trigger trg_notify_event_registration
after insert on public.event_registrations
for each row execute function public.notify_on_event_registration();
