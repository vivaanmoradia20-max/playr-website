-- ============================================================
-- PLAYR — Row Level Security Policies
-- Run after 01_schema.sql
-- ============================================================

alter table public.profiles enable row level security;
alter table public.sports enable row level security;
alter table public.user_sports enable row level security;
alter table public.communities enable row level security;
alter table public.community_members enable row level security;
alter table public.posts enable row level security;
alter table public.follows enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.challenges enable row level security;
alter table public.challenge_results enable row level security;
alter table public.events enable row level security;
alter table public.event_registrations enable row level security;
alter table public.event_follows enable row level security;
alter table public.notifications enable row level security;
alter table public.subscriptions enable row level security;
alter table public.products enable row level security;
alter table public.cart_items enable row level security;

-- ---------------- PROFILES ----------------
create policy "profiles_select_all" on public.profiles for select using (true);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);

-- ---------------- SPORTS (read-only for clients; managed by admins via service role) ----------------
create policy "sports_select_all" on public.sports for select using (true);

-- ---------------- USER_SPORTS ----------------
create policy "user_sports_select_all" on public.user_sports for select using (true);
create policy "user_sports_insert_own" on public.user_sports for insert with check (auth.uid() = user_id);
create policy "user_sports_delete_own" on public.user_sports for delete using (auth.uid() = user_id);

-- ---------------- COMMUNITIES ----------------
create policy "communities_select_all" on public.communities for select using (true);
create policy "communities_insert_auth" on public.communities for insert with check (auth.uid() = created_by);
create policy "communities_update_owner" on public.communities for update using (auth.uid() = created_by);
create policy "communities_delete_owner" on public.communities for delete using (auth.uid() = created_by);

-- ---------------- COMMUNITY_MEMBERS ----------------
create policy "community_members_select_all" on public.community_members for select using (true);
create policy "community_members_insert_own" on public.community_members for insert with check (auth.uid() = user_id);
create policy "community_members_delete_own_or_owner" on public.community_members for delete
  using (
    auth.uid() = user_id
    or auth.uid() = (select created_by from public.communities c where c.id = community_id)
  );

-- ---------------- POSTS ----------------
create policy "posts_select_all" on public.posts for select using (true);
create policy "posts_insert_own" on public.posts for insert with check (auth.uid() = user_id);
create policy "posts_update_own" on public.posts for update using (auth.uid() = user_id);
create policy "posts_delete_own" on public.posts for delete using (auth.uid() = user_id);

-- ---------------- FOLLOWS ----------------
create policy "follows_select_all" on public.follows for select using (true);
create policy "follows_insert_own" on public.follows for insert with check (auth.uid() = follower_id);
create policy "follows_delete_own" on public.follows for delete using (auth.uid() = follower_id);

-- ---------------- LIKES ----------------
create policy "likes_select_all" on public.likes for select using (true);
create policy "likes_insert_own" on public.likes for insert with check (auth.uid() = user_id);
create policy "likes_delete_own" on public.likes for delete using (auth.uid() = user_id);

-- ---------------- COMMENTS ----------------
create policy "comments_select_all" on public.comments for select using (true);
create policy "comments_insert_own" on public.comments for insert with check (auth.uid() = user_id);
create policy "comments_update_own" on public.comments for update using (auth.uid() = user_id);
create policy "comments_delete_own" on public.comments for delete using (auth.uid() = user_id);

-- ---------------- CHALLENGES ----------------
create policy "challenges_select_all" on public.challenges for select using (true);
create policy "challenges_insert_own" on public.challenges for insert with check (auth.uid() = creator_id);
create policy "challenges_update_participant" on public.challenges for update
  using (auth.uid() = creator_id or auth.uid() = opponent_id);
create policy "challenges_delete_creator" on public.challenges for delete using (auth.uid() = creator_id);

-- ---------------- CHALLENGE_RESULTS ----------------
create policy "challenge_results_select_all" on public.challenge_results for select using (true);
create policy "challenge_results_insert_own" on public.challenge_results for insert with check (auth.uid() = user_id);
create policy "challenge_results_update_own" on public.challenge_results for update using (auth.uid() = user_id);
create policy "challenge_results_delete_own" on public.challenge_results for delete using (auth.uid() = user_id);

-- ---------------- EVENTS ----------------
create policy "events_select_all" on public.events for select using (true);
create policy "events_insert_auth" on public.events for insert with check (auth.uid() = created_by);
create policy "events_update_owner" on public.events for update using (auth.uid() = created_by);
create policy "events_delete_owner" on public.events for delete using (auth.uid() = created_by);

-- ---------------- EVENT_REGISTRATIONS ----------------
create policy "event_regs_select_own" on public.event_registrations for select using (auth.uid() = user_id);
create policy "event_regs_insert_own" on public.event_registrations for insert with check (auth.uid() = user_id);
create policy "event_regs_delete_own" on public.event_registrations for delete using (auth.uid() = user_id);

-- ---------------- EVENT_FOLLOWS ----------------
create policy "event_follows_select_all" on public.event_follows for select using (true);
create policy "event_follows_insert_own" on public.event_follows for insert with check (auth.uid() = user_id);
create policy "event_follows_delete_own" on public.event_follows for delete using (auth.uid() = user_id);

-- ---------------- NOTIFICATIONS ----------------
-- Inserted only by SECURITY DEFINER trigger functions, never directly by clients.
create policy "notifications_select_own" on public.notifications for select using (auth.uid() = user_id);
create policy "notifications_update_own" on public.notifications for update using (auth.uid() = user_id);

-- ---------------- SUBSCRIPTIONS ----------------
create policy "subscriptions_select_own" on public.subscriptions for select using (auth.uid() = user_id);
create policy "subscriptions_insert_own" on public.subscriptions for insert with check (auth.uid() = user_id);
create policy "subscriptions_update_own" on public.subscriptions for update using (auth.uid() = user_id);

-- ---------------- PRODUCTS (read-only for clients; managed by admins via service role) ----------------
create policy "products_select_all" on public.products for select using (true);

-- ---------------- CART_ITEMS ----------------
create policy "cart_select_own" on public.cart_items for select using (auth.uid() = user_id);
create policy "cart_insert_own" on public.cart_items for insert with check (auth.uid() = user_id);
create policy "cart_update_own" on public.cart_items for update using (auth.uid() = user_id);
create policy "cart_delete_own" on public.cart_items for delete using (auth.uid() = user_id);
