# PLAYR — Supabase MVP: Setup Guide

This turns the static PLAYR prototype into a working full-stack app on Supabase,
**without changing the visual design, layout, navigation, or branding.**

## What you got

```
playr/
├── index.html              ← the original UI, wired to Supabase (was playr.html)
├── config.js                ← put your Supabase URL + anon key here
├── js/
│   ├── supabase-client.js   ← the entire API layer (auth, CRUD, storage, search, realtime)
│   └── app.js                ← wires that API into the existing PLAYR screens
└── sql/
    ├── 01_schema.sql        ← all tables, triggers, counters, notification triggers
    ├── 02_rls_policies.sql  ← row level security for every table
    ├── 03_storage.sql       ← 4 storage buckets + policies
    └── 04_seed.sql          ← optional: seeds the 21 sports + shop products so it
                                looks like the original demo on first load
```

## 1. Create the Supabase project

1. Go to https://supabase.com/dashboard → **New project**.
2. Pick a name, a database password, and a region close to your users.
3. Wait for provisioning (~2 minutes).

## 2. Run the SQL, in order

Open **SQL Editor** in the Supabase dashboard and run each file's contents,
**in this order** (each depends on the previous one):

1. `sql/01_schema.sql` — tables, triggers, counters, notification triggers.
2. `sql/02_rls_policies.sql` — locks every table down with Row Level Security.
3. `sql/03_storage.sql` — creates the 4 storage buckets and their policies.
4. `sql/04_seed.sql` *(optional)* — seeds sports + products so the app isn't empty.

You can paste each file's full contents into a new SQL Editor query and hit Run.

## 3. Configure Auth

In **Authentication → Providers**, Email/Password is on by default — that's all
PLAYR needs for sign up / login / forgot password.

In **Authentication → URL Configuration**, set your **Site URL** to wherever
you'll host `index.html` (e.g. `http://localhost:5500` while testing, or your
production domain later). This is what "forgot password" email links redirect to.

Optional but recommended for a nicer signup flow: **Authentication → Email
Templates** — customize the "Confirm signup" and "Reset password" templates
with PLAYR branding. Not required for the MVP to function.

## 4. Get your API credentials

**Project Settings → API**, copy:
- **Project URL**
- **anon / public key** (never use the `service_role` key in the frontend)

Paste them into `config.js`:

```js
window.PLAYR_ENV = {
  SUPABASE_URL: "https://xxxxxxxx.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOi..."
};
```

## 5. Run it

This is a static site — no build step. Any static file server works:

```bash
cd playr
npx serve .
# or: python3 -m http.server 5500
```

Open the printed URL. Sign up for an account (check your email for the Supabase
confirmation link, unless you've turned confirmation off in Authentication →
Providers → Email for faster local testing), log in, and everything — following
sports, posting, liking, commenting, joining communities, creating challenges,
registering for events, notifications, PLAYR+ activation, and the shop cart —
now persists in your Supabase Postgres database.

## What's real vs. intentionally left as illustrative content

Per your instruction not to redesign PLAYR, the marketing/editorial shell was
left untouched, and a few pieces of **decorative** content were intentionally
left static because they aren't part of the 20 requested features/schema:

- The hero ticker (`heroTicker`) — a scrolling live-scores strip, not app data.
- Per-sport "Latest / History / Athletes" editorial tabs inside **Sport
  Universe** — these are magazine-style content, not in the requested `sports`
  table schema. The **Feed**, **Follow button**, **Follower count**,
  **Challenges**, **Events** and **Stats** tabs inside Sport Universe *are*
  live from Supabase.
- The Events "hub" sub-tabs (Fixtures / Results / Teams / Highlights /
  Merchandise) inside an individual event's detail page — these need a
  fixtures/results data model you didn't ask for (`events` +
  `event_registrations` + `event_follows` were the requested tables, and
  those are fully wired).
- The "Limited Drop" claim counter in Shop is a cosmetic counter, not a
  requested table.
- The Profile page's second tab ("Ava Chen · Creator") is left as an
  illustrative example profile; the first tab ("Athlete") now shows the
  real logged-in user's data, editable via "Edit Profile".

Everything else in the 20-point spec — auth, profiles, sports follow, posts
(create/upload/view/delete), user follows, likes, comments, communities
(create/join/leave/post), challenges (create/challenge/accept/submit
result/leaderboard), events (view/follow/register), notifications (including
realtime), PLAYR+ demo activation, shop + persistent cart, and cross-entity
search — reads and writes real Supabase data, behind RLS.

## Extending further

Every feature funnels through `window.PlayrAPI` in `js/supabase-client.js`
(`Auth`, `Profiles`, `Sports`, `Posts`, `Follows`, `Likes`, `Comments`,
`Communities`, `Challenges`, `Events`, `Notifications`, `Subscriptions`,
`Shop`, `Search`). To wire up any of the "illustrative" pieces above later,
add the table(s) you need to `sql/01_schema.sql` + policies, add a method to
the matching object in `supabase-client.js`, then call it from `js/app.js` —
the same pattern used everywhere else in the file.

## Production notes

- The `products` and `sports` tables are read-only for clients by design
  (no RLS insert/update policy) — manage the catalog via the Supabase
  dashboard's Table Editor, or with a service-role key from a trusted
  backend/admin tool, not from the browser.
- PLAYR+ and Shop checkout have **no real payment processing** — as
  requested, `Subscriptions.activateDemo()` just flips a status flag, and
  the cart has no checkout button, only quantity management. Wire a real
  payment provider (Razorpay, Stripe) when you're ready.
- All storage buckets are public-read with owner-scoped write policies
  (uploads go to `<bucket>/<user_id>/...`), which is standard for a social
  app's public media.
