/* ============================================================
   PLAYR — Supabase project config
   Fill these in from your Supabase project:
   Dashboard → Project Settings → API
   ============================================================ */
window.PLAYR_ENV = {
  SUPABASE_URL: "https://YOUR-PROJECT-REF.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-PUBLIC-ANON-KEY"
};
