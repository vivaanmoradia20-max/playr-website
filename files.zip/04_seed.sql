-- ============================================================
-- PLAYR — Seed data (optional but recommended)
-- Populates sports + products so the app looks the same on
-- first run as the original static prototype.
-- ============================================================

insert into public.sports (name, category, image_url, follower_count) values
('Cricket','Team Sports','https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=800&h=900&fit=crop',8200000),
('Football','Team Sports','https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=800&h=900&fit=crop',11600000),
('Running','Individual','https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&h=900&fit=crop',5400000),
('Basketball','Team Sports','https://images.unsplash.com/photo-1546519638-68e109498ffc?w=800&h=900&fit=crop',6700000),
('Mountaineering','Adventure','https://images.unsplash.com/photo-1522163182402-834f871fd851?w=800&h=900&fit=crop',2400000),
('Tennis','Individual','https://images.unsplash.com/photo-1595435742656-5272d0b3fa82?w=800&h=900&fit=crop',4100000),
('Swimming','Water','https://images.unsplash.com/photo-1530549387789-4c1017266635?w=800&h=900&fit=crop',3300000),
('Cycling','Individual','https://images.unsplash.com/photo-1541625602330-2277a4c46182?w=800&h=900&fit=crop',2900000),
('Motorsport','Motorsport','https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=800&h=900&fit=crop',5800000),
('Athletics','Individual','https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&h=900&fit=crop',3600000),
('Boxing','Combat','https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=800&h=900&fit=crop',2700000),
('Golf','Individual','https://images.unsplash.com/photo-1535131749006-b7f58c99034b?w=800&h=900&fit=crop',1900000),
('Badminton','Individual','https://images.unsplash.com/photo-1613918431703-aa50609a1b78?w=800&h=900&fit=crop',2200000),
('Chess','Mind Sports','https://images.unsplash.com/photo-1528819622765-d6bcf132ac11?w=800&h=900&fit=crop',3000000),
('Esports','Esports','https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&h=900&fit=crop',9100000),
('Volleyball','Team Sports','https://images.unsplash.com/photo-1592656094267-764a45160876?w=800&h=900&fit=crop',1600000),
('Hockey','Team Sports','https://images.unsplash.com/photo-1580891721764-2d3fb2ce7233?w=800&h=900&fit=crop',2100000),
('Table Tennis','Individual','https://images.unsplash.com/photo-1534158914592-062992fbe900?w=800&h=900&fit=crop',1400000),
('Gymnastics','Individual','https://images.unsplash.com/photo-1518611012118-696072aa579a?w=800&h=900&fit=crop',1200000),
('Surfing','Water','https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=800&h=900&fit=crop',980000),
('Skiing','Winter','https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=800&h=900&fit=crop',870000)
on conflict (name) do nothing;

insert into public.products (name, category, price, image_url) values
('AeroStride Running Shoes','Running',4299,'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&h=900&fit=crop'),
('Pro Willow Cricket Bat','Cricket',6499,'https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=800&h=900&fit=crop'),
('Match-Ready Football Jersey','Football',1899,'https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=800&h=900&fit=crop'),
('Court Grip Basketball','Basketball',1299,'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=800&h=900&fit=crop'),
('Trail Hydration Pack','Outdoor',2199,'https://images.unsplash.com/photo-1522163182402-834f871fd851?w=800&h=900&fit=crop'),
('Insulated Water Bottle','Fitness',799,'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&h=900&fit=crop'),
('Aero Cycling Helmet','Outdoor',3499,'https://images.unsplash.com/photo-1541625602330-2277a4c46182?w=800&h=900&fit=crop'),
('Racing Gloves','Motorsport',2899,'https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=800&h=900&fit=crop'),
('PLAYR Logo Tee','Merch',899,'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&h=900&fit=crop'),
('PLAYR Hoodie','Merch',2199,'https://images.unsplash.com/photo-1528819622765-d6bcf132ac11?w=800&h=900&fit=crop'),
('PLAYR Cap','Merch',699,'https://images.unsplash.com/photo-1535131749006-b7f58c99034b?w=800&h=900&fit=crop'),
('PLAYR Sports Bag','Merch',1599,'https://images.unsplash.com/photo-1613918431703-aa50609a1b78?w=800&h=900&fit=crop')
on conflict do nothing;
