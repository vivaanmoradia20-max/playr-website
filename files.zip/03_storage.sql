-- ============================================================
-- PLAYR — Supabase Storage buckets + policies
-- Run after 01_schema.sql and 02_rls_policies.sql
-- Files are stored under a path prefixed with the uploader's
-- auth.uid(), e.g. profile-images/<user_id>/avatar.jpg
-- ============================================================

insert into storage.buckets (id, name, public)
values
  ('profile-images', 'profile-images', true),
  ('post-media', 'post-media', true),
  ('community-images', 'community-images', true),
  ('product-images', 'product-images', true)
on conflict (id) do nothing;

-- ---------------- Public read on all four buckets ----------------
create policy "public_read_profile_images" on storage.objects
  for select using (bucket_id = 'profile-images');
create policy "public_read_post_media" on storage.objects
  for select using (bucket_id = 'post-media');
create policy "public_read_community_images" on storage.objects
  for select using (bucket_id = 'community-images');
create policy "public_read_product_images" on storage.objects
  for select using (bucket_id = 'product-images');

-- ---------------- profile-images: owner-only write, path = <uid>/... ----------------
create policy "profile_images_insert_own" on storage.objects
  for insert with check (
    bucket_id = 'profile-images' and (storage.foldername(name))[1] = auth.uid()::text
  );
create policy "profile_images_update_own" on storage.objects
  for update using (
    bucket_id = 'profile-images' and (storage.foldername(name))[1] = auth.uid()::text
  );
create policy "profile_images_delete_own" on storage.objects
  for delete using (
    bucket_id = 'profile-images' and (storage.foldername(name))[1] = auth.uid()::text
  );

-- ---------------- post-media: owner-only write, path = <uid>/... ----------------
create policy "post_media_insert_own" on storage.objects
  for insert with check (
    bucket_id = 'post-media' and (storage.foldername(name))[1] = auth.uid()::text
  );
create policy "post_media_update_own" on storage.objects
  for update using (
    bucket_id = 'post-media' and (storage.foldername(name))[1] = auth.uid()::text
  );
create policy "post_media_delete_own" on storage.objects
  for delete using (
    bucket_id = 'post-media' and (storage.foldername(name))[1] = auth.uid()::text
  );

-- ---------------- community-images: any authenticated user can upload (community creation flow) ----------------
create policy "community_images_insert_auth" on storage.objects
  for insert with check (
    bucket_id = 'community-images' and auth.role() = 'authenticated'
  );
create policy "community_images_update_own" on storage.objects
  for update using (
    bucket_id = 'community-images' and (storage.foldername(name))[1] = auth.uid()::text
  );
create policy "community_images_delete_own" on storage.objects
  for delete using (
    bucket_id = 'community-images' and (storage.foldername(name))[1] = auth.uid()::text
  );

-- ---------------- product-images: admin/service-role only (no client insert policy) ----------------
-- Intentionally no insert/update/delete policy for authenticated users.
-- Manage the product catalog via the Supabase Dashboard or service-role key.
